/* 現場ポケット（仮称）— Service Worker（PWAの薄皮・W2-1）
   正本: knowledge/fable5_legacy/SPEC_W2-1_GENBA_POCKET_UI_2026-07-19.md §4

   版の文字列は「index.html の GP_VERSION 1箇所」だけで定義する。
   ここでは register("sw.js?v=" + GP_VERSION) で渡された ?v= を読んで
   キャッシュ名にする＝版の二重定義をしない（受入テスト T18）。

   自動更新はしない。新しい版は index.html の
   「🔄 あたらしくする」を人が押したときだけ有効になる（B1系＝勝手に何も起きない）。
*/
"use strict";

var GP_VER = new URL(self.location.href).searchParams.get("v") || "0";
var CACHE = "genba-pocket-" + GP_VER;

var ASSETS = [
  "./",
  "./index.html",
  "./manifest.json"
];

self.addEventListener("install", function (e) {
  /* skipWaiting は しない＝人が「🔄あたらしくする」を押すまで 待機する */
  e.waitUntil(
    caches.open(CACHE).then(function (c) {
      return Promise.all(ASSETS.map(function (u) {
        return c.add(u).catch(function () { /* 1本ダメでも 導入は 続ける */ });
      }));
    })
  );
});

self.addEventListener("activate", function (e) {
  e.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.map(function (k) {
        if (k !== CACHE && k.indexOf("genba-pocket-") === 0) return caches.delete(k);
      }));
    }).then(function () { return self.clients.claim(); })
  );
});

self.addEventListener("message", function (e) {
  if (e.data && e.data.type === "SKIP_WAITING") self.skipWaiting();
});

self.addEventListener("fetch", function (e) {
  var req = e.request;
  if (req.method !== "GET") return;
  var url = new URL(req.url);
  if (url.origin !== self.location.origin) return;   /* 外へは 取りに いかない（W3） */

  /* 共有シート（share_target GET）で ?title=... が付いて来ても
     中身は同じ index.html を返す＝オフラインでも 受け口が 生きる */
  e.respondWith(
    caches.match(req, { ignoreSearch: true }).then(function (hit) {
      if (hit) return hit;
      return fetch(req).then(function (res) {
        if (res && res.ok && res.type === "basic") {
          var copy = res.clone();
          caches.open(CACHE).then(function (c) { c.put(req, copy); });
        }
        return res;
      }).catch(function () {
        return caches.match("./index.html", { ignoreSearch: true });
      });
    })
  );
});
