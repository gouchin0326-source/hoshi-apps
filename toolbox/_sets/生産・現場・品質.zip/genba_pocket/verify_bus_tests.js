/*!
 * verify_bus_tests.js — 設計書 §6 の受入テスト H1〜H10 を実走させるランナー
 * 使い方: node verify_bus_tests.js
 * 方針: verify_bus.js を子プロセスとして実際に起動し、exit code と 出力の両方を見る。
 *       H6（ブラウザ実ロード）は node からは判定できないので「判定不能」として扱い、
 *       PASS 数には数えない（fail-closed）。
 */
'use strict';

var cp = require('child_process');
var fs = require('fs');
var path = require('path');
var os = require('os');

var HERE = __dirname;
var TARGET = path.join(HERE, 'verify_bus.js');
var TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'verify_bus_h_'));

function write(name, obj) {
  var p = path.join(TMP, name);
  fs.writeFileSync(p, typeof obj === 'string' ? obj : JSON.stringify(obj, null, 1), 'utf8');
  return p;
}

function run(args) {
  var r = cp.spawnSync(process.execPath, [TARGET].concat(args), { encoding: 'utf8' });
  return { code: r.status, out: (r.stdout || '') + (r.stderr || '') };
}

var results = [];
function H(id, purpose, fn) {
  var verdict, note;
  try {
    var v = fn();
    verdict = v.verdict; note = v.note;
  } catch (e) {
    verdict = 'FAIL'; note = '例外: ' + e.message;
  }
  results.push({ id: id, purpose: purpose, verdict: verdict, note: note });
}

/* ---- 共通fixture ---- */
function qItem(over) {
  var b = { id: 'gp-1752900000000-0001', capturedAt: '2026-07-19T10:00:00+09:00',
            source: 'manual', type: 'text', raw: 'ふつうの もじ', extracted: null, status: 'raw', note: '' };
  for (var k in (over || {})) b[k] = over[k];
  return b;
}
function queueDoc(items, over) {
  var d = { app: 'genba_pocket', kind: 'capture_queue', version: 1, device: 'たんまつA', items: items };
  for (var k in (over || {})) d[k] = over[k];
  return d;
}

/* ---- H1 ---- */
H('H1', 'selftest が 正形3件PASS・異形10件が期待コードでFAIL・exit 0', function () {
  var r = run(['--selftest']);
  var ok = r.code === 0 && /けっか: PASS/.test(r.out) && !/^NG /m.test(r.out);
  return { verdict: ok ? 'PASS' : 'FAIL', note: 'exit=' + r.code + ' / ' + (r.out.match(/# けっか:.*/) || [''])[0] };
});

/* ---- H2 変異注入 ---- */
H('H2', '異形1件の期待コードを故意に壊す → selftest が exit 1', function () {
  var r = run(['--selftest', '--inject', '3']);
  var ok = r.code === 1 && /^NG /m.test(r.out);
  return { verdict: ok ? 'PASS' : 'FAIL', note: 'exit=' + r.code + ' / NG行=' + ((r.out.match(/^NG .*/m) || [''])[0]).slice(0, 60) };
});

/* ---- H3 <script> 本文は合法 ---- */
H('H3', 'raw に <script>alert(1)</script> を含む正形 → PASS（E05を誤発火しない）', function () {
  var f = write('h3.json', queueDoc([qItem({ raw: '<script>alert(1)</script> のこしたい もじ' })]));
  var r = run([f, '--kind', 'queue']);
  var ok = r.code === 0 && !/E05/.test(r.out);
  return { verdict: ok ? 'PASS' : 'FAIL', note: 'exit=' + r.code + ' / E05出現=' + /E05/.test(r.out) };
});

/* ---- H4 危険スキーム ---- */
H('H4', 'url:"javascript:alert(1)" → E05 で FAIL', function () {
  var f = write('h4.json', { _batch: true, items: [{ site: 'a', title: 'x', price: 1, url: 'javascript:alert(1)' }] });
  var r = run([f, '--kind', 'c1']);
  var ok = r.code === 1 && /^E05 /m.test(r.out);
  return { verdict: ok ? 'PASS' : 'FAIL', note: 'exit=' + r.code + ' / ' + ((r.out.match(/^E05 .*/m) || [''])[0]).slice(0, 70) };
});

/* ---- H5 未知キーは警告のみ ---- */
H('H5', '未知キー color:"red" 追加 → W01 警告のみ・exit 0', function () {
  var it = qItem(); it.color = 'red';
  var f = write('h5.json', queueDoc([it], { color: 'red' }));
  var r = run([f, '--kind', 'queue']);
  var ok = r.code === 0 && /^W01 /m.test(r.out) && !/^E\d\d /m.test(r.out);
  return { verdict: ok ? 'PASS' : 'FAIL', note: 'exit=' + r.code + ' / W01数=' + (r.out.match(/^W01 /gm) || []).length };
});

/* ---- H6 ブラウザ（node からは判定不能） ---- */
H('H6', 'ブラウザで <script src> 読込 → BusVerify.verify が関数・console error 0', function () {
  var page = path.join(HERE, 'verify_bus_browser_test.html');
  var exists = fs.existsSync(page);
  return { verdict: 'UNDETERMINED',
           note: (exists ? 'テストページ有り: ' : 'テストページが 見つからない: ') + page + ' — ブラウザ実ロードで別途判定（node では判定できない）' };
});

/* ---- H7 diff 項目消失 ---- */
H('H7', '--diff で項目1件を消した新JSON → E20・exit 1／--allow-delete なら exit 0', function () {
  var oldP = write('h7_old.json', queueDoc([qItem({ id: 'gp-A' }), qItem({ id: 'gp-B' })]));
  var newP = write('h7_new.json', queueDoc([qItem({ id: 'gp-A' })]));
  var r1 = run(['--diff', oldP, newP, '--kind', 'queue']);
  var r2 = run(['--diff', oldP, newP, '--kind', 'queue', '--allow-delete']);
  var ok = r1.code === 1 && /^E20 /m.test(r1.out) && r2.code === 0;
  return { verdict: ok ? 'PASS' : 'FAIL', note: '通常 exit=' + r1.code + '(E20=' + /E20/.test(r1.out) + ') / --allow-delete exit=' + r2.code };
});

/* ---- H8 status後退 ---- */
H('H8', '--diff で status を exported→raw に戻した新JSON → E21', function () {
  var oldP = write('h8_old.json', queueDoc([qItem({ id: 'gp-A', status: 'exported' })]));
  var newP = write('h8_new.json', queueDoc([qItem({ id: 'gp-A', status: 'raw' })]));
  var r = run(['--diff', oldP, newP, '--kind', 'queue']);
  var ok = r.code === 1 && /^E21 /m.test(r.out);
  return { verdict: ok ? 'PASS' : 'FAIL', note: 'exit=' + r.code + ' / ' + ((r.out.match(/^E21 .*/m) || [''])[0]).slice(0, 70) };
});

/* ---- H9 引数なし ---- */
H('H9', '引数なし実行 → 使い方表示・exit 2（0でも1でもない）', function () {
  var r = run([]);
  var ok = r.code === 2 && /つかいかた/.test(r.out);
  return { verdict: ok ? 'PASS' : 'FAIL', note: 'exit=' + r.code + ' / 使い方表示=' + /つかいかた/.test(r.out) };
});

/* ---- H10 壊れたJSON ---- */
H('H10', '壊れたJSON（{"a": ）→ E00・例外で落ちずに exit 1', function () {
  var f = write('h10.json', '{"a":');
  var r = run([f, '--kind', 'queue']);
  var ok = r.code === 1 && /^E00 /m.test(r.out) && /判定不能/.test(r.out) && !/Unexpected token[\s\S]*at Object/.test(r.out);
  return { verdict: ok ? 'PASS' : 'FAIL', note: 'exit=' + r.code + ' / E00=' + /E00/.test(r.out) + ' / 判定不能表示=' + /判定不能/.test(r.out) };
});

/* ---- 集計 ---- */
var pass = results.filter(function (r) { return r.verdict === 'PASS'; }).length;
var fail = results.filter(function (r) { return r.verdict === 'FAIL'; }).length;
var und = results.filter(function (r) { return r.verdict === 'UNDETERMINED'; }).length;

console.log('# 受入テスト H1〜H10（SPEC_W2-2 §6）  対象: ' + TARGET);
results.forEach(function (r) {
  console.log(r.verdict.padEnd(13) + r.id.padEnd(5) + r.purpose);
  console.log('             ' + '  └ ' + r.note);
});
console.log('# けっか: PASS ' + pass + ' / FAIL ' + fail + ' / 判定不能 ' + und + ' （全 ' + results.length + '）');
console.log('# 判定不能は 合格に かぞえません（fail-closed）');
process.exitCode = (fail === 0 && und === 0) ? 0 : 1;
