/* G3系統検収デスク 埋込受入テスト（決定論のみ・LLM不使用・乱数不使用）
   実行: node tests/test_kenshu_g3_desk.js
   設計書: SPEC_W1-3_KENSHU_DESK_2026-07-18.md §6（W1-3a..e の検証条件）
           親書 LEGACY_BIZAPP_SUMMIT_2026-07-17.md §C（I/O契約）・§G-4/6（コーナーケース） */
"use strict";
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const ROOT = path.resolve(__dirname, "..");
const HTML_PATH = path.join(ROOT, "index.html");
const FIX_A = path.join(ROOT, "fixtures", "lineage_fixture_3fam10.json");
const FIX_B = path.join(ROOT, "fixtures", "lineage_fixture_mini6.json");

const html = fs.readFileSync(HTML_PATH, "utf8");
const textA = fs.readFileSync(FIX_A, "utf8");
const textB = fs.readFileSync(FIX_B, "utf8");

/* ---- CORE領域の抽出（fail-closed: 見つからなければ止める） ---- */
function coreSource(src) {
  const b = src.indexOf("/* ===== CORE:BEGIN");
  const e = src.indexOf("/* ===== CORE:END");
  if (b < 0 || e < 0 || e <= b) { throw new Error("CORE領域が index.html に見つからない"); }
  return src.slice(b, e);
}
function loadCore(coreSrc) {
  return new Function("var module=undefined;" + coreSrc + "\nreturn KG3;")();
}
const CORE_SRC = coreSource(html);
const KG3 = loadCore(CORE_SRC);

/* ---- テストハーネス ---- */
let pass = 0, fail = 0;
const failures = [];
function T(id, name, fn) {
  try { fn(); pass++; console.log("PASS " + id + " " + name); }
  catch (e) { fail++; failures.push(id + " " + name + " :: " + e.message); console.log("FAIL " + id + " " + name + " :: " + e.message); }
}
function eq(a, b, msg) {
  const sa = JSON.stringify(a), sb = JSON.stringify(b);
  if (sa !== sb) { throw new Error((msg || "不一致") + "\n  実際=" + sa + "\n  期待=" + sb); }
}
function ok(c, msg) { if (!c) { throw new Error(msg || "偽"); } }
function throws(fn, msg) {
  let threw = false;
  try { fn(); } catch (e) { threw = true; }
  if (!threw) { throw new Error(msg || "例外が出るべきところで出なかった"); }
}
function slugs(list) { return list.map(x => x.slug); }
function freshA(K) {
  K = K || KG3;
  const p = K.parseLineage(textA);
  const r = K.mergeImport(null, p.lineage, p.hash, "2026-07-19T00:00:00.000Z");
  return { p, state: r.state, queue: r.queue, lineage: p.lineage };
}

/* =========================================================
   W1-3a  キュー純関数 + パック割り
   ========================================================= */
T("T-a0", "sha256 自前実装が node crypto と一致（外部読込なしの決定論ハッシュ）", () => {
  eq(KG3.sha256hex("abc"), crypto.createHash("sha256").update("abc").digest("hex"), "abc");
  eq(KG3.sha256hex(""), crypto.createHash("sha256").update("").digest("hex"), "空文字");
  eq(KG3.sha256hex(textA), crypto.createHash("sha256").update(textA, "utf8").digest("hex"), "fixtureA全文");
  eq(KG3.sha256hex("族・代表 🈚"), crypto.createHash("sha256").update("族・代表 🈚", "utf8").digest("hex"), "日本語+絵文字");
});

T("T-a1", "族順・件順が期待値表と完全一致（族=平均score降順／族内=代表→B級フル→ミニ→抜き打ち）", () => {
  const { queue } = freshA();
  eq(slugs(queue.items), ["b_rep", "b_m1", "b_m2", "b_m3", "a_rep", "a_bfull", "c_rep", "c_m2", "c_spot"]);
  eq(queue.excluded.map(x => x.slug + ":" + x.reason), ["c_c1:rankC"], "Cランクは検収に回さない");
});

T("T-a2", "決定論: 同一入力を2回処理して完全一致", () => {
  const p1 = KG3.parseLineage(textA), p2 = KG3.parseLineage(textA);
  eq(p1.hash, p2.hash);
  const q1 = KG3.buildQueue(p1.lineage), q2 = KG3.buildQueue(p2.lineage);
  eq(q1, q2, "キュー");
  eq(KG3.buildPacks(q1.items, p1.hash, 2), KG3.buildPacks(q2.items, p2.hash, 2), "パック列");
});

T("T-a3", "パック割りが期待値表と完全一致（フル1+ミニ3／フル2／端数）", () => {
  const { p, queue } = freshA();
  const packs = KG3.buildPacks(queue.items, p.hash, 2);
  eq(packs.map(x => slugs(x.items)), [
    ["b_rep", "b_m1", "b_m2", "b_m3"], ["a_rep", "a_bfull"], ["c_rep", "c_m2"], ["c_spot"]]);
  eq(packs.map(KG3.packType), ["フル1+ミニ3", "フル2", "はんぱ", "はんぱ"]);
  eq(packs.map(x => x.thirds), [6, 6, 4, 3], "枠の消費（1枠=3）");
  eq(packs.map(x => x.minutes), [9.5, 10, 6.5, 5], "分の見積り");
});

T("T-a4", "パックは族境界を跨がない", () => {
  const { p, queue } = freshA();
  KG3.buildPacks(queue.items, p.hash, 2).forEach(pk => {
    pk.items.forEach(it => { eq(it.family_key, pk.family_key, "跨いだ: " + pk.pack_id); });
  });
});

T("T-a5", "パックID = P001からの連番 + lineage取込ハッシュ先頭8桁", () => {
  const { p, queue } = freshA();
  const packs = KG3.buildPacks(queue.items, p.hash, 2);
  eq(p.hash.length, 8, "ハッシュ8桁");
  eq(packs.map(x => x.pack_id), ["P001-" + p.hash, "P002-" + p.hash, "P003-" + p.hash, "P004-" + p.hash]);
});

T("T-a6", "ミニ6型のパックが出る（1族=代表1+ミニ9）", () => {
  const p = KG3.parseLineage(textB);
  const q = KG3.buildQueue(p.lineage);
  const packs = KG3.buildPacks(q.items, p.hash, 2);
  eq(packs.map(KG3.packType), ["フル1+ミニ3", "ミニ6"]);
  eq(packs[1].items.length, 6);
});

T("T-a7", "満杯パック（1枠=3・2枠=6）の形は3型のみ", () => {
  [textA, textB].forEach(t => {
    const p = KG3.parseLineage(t);
    const q = KG3.buildQueue(p.lineage);
    KG3.buildPacks(q.items, p.hash, 2).forEach(pk => {
      if (pk.thirds === 6) { ok(["フル2", "フル1+ミニ3", "ミニ6"].indexOf(KG3.packType(pk)) >= 0, "型外: " + KG3.packType(pk)); }
    });
  });
});

/* =========================================================
   W1-3b  判定 + 永続 + ⏸ + fail-closed
   ========================================================= */
T("T-b1", "判定はJSON往復（保存→読み直し）で残る", () => {
  const { state } = freshA();
  KG3.applyVerdict(state, "b_rep", "pass", "2026-07-19T01:00:00.000Z", "P001-xxxxxxxx");
  const back = JSON.parse(JSON.stringify(state));
  eq(back.items.b_rep.status, "pass");
  eq(back.items.b_rep.checked_at, "2026-07-19T01:00:00.000Z");
  eq(back.items.b_rep.checker, "干場");
  eq(back.items.b_rep.pack_id, "P001-xxxxxxxx");
  eq(back.schema, "kenshu_g3_v1");
});

T("T-b2", "さしもどしは理由が空なら確定できない（fail-closed）", () => {
  const { state } = freshA();
  throws(() => KG3.applyVerdict(state, "b_m1", "reject", "2026-07-19T01:00:00.000Z", "P001"), "理由なしで通った");
  eq(state.items.b_m1.status, "pending", "失敗時に状態を変えない");
  KG3.setNote(state, "b_m1", "  ");
  throws(() => KG3.applyVerdict(state, "b_m1", "reject", "2026-07-19T01:00:00.000Z", "P001"), "空白だけで通った");
  KG3.setNote(state, "b_m1", "保存できない");
  KG3.applyVerdict(state, "b_m1", "reject", "2026-07-19T01:00:00.000Z", "P001");
  eq(state.items.b_m1.status, "reject");
});

T("T-b3", "⏸あとで は その族の末尾に回る", () => {
  const { state, queue } = freshA();
  KG3.applyVerdict(state, "b_rep", "deferred", "2026-07-19T01:00:00.000Z", "P001");
  eq(slugs(KG3.remainingQueue(state, queue.items)),
    ["b_m1", "b_m2", "b_m3", "b_rep", "a_rep", "a_bfull", "c_rep", "c_m2", "c_spot"]);
  eq(state.items.b_rep.checked_at, null, "あとで は 確認日時を持たない");
});

T("T-b4", "チェック・メモは即時に状態へ入る／範囲外は例外（fail-closed）", () => {
  const { state } = freshA();
  eq(state.items.b_rep.checks.length, 6, "大チェック=タスク3+3問");
  eq(state.items.b_m1.checks.length, 3, "小チェック=3点");
  KG3.setCheck(state, "b_rep", 0, true);
  eq(state.items.b_rep.checks[0], true);
  throws(() => KG3.setCheck(state, "b_rep", 9, true), "範囲外が通った");
  throws(() => KG3.setCheck(state, "no_such", 0, true), "未知slugが通った");
  throws(() => KG3.applyVerdict(state, "b_rep", "maybe", "2026-07-19T01:00:00.000Z", "P001"), "未知の判定が通った");
  throws(() => KG3.applyVerdict(state, "b_rep", "pass", null, "P001"), "日時なしが通った");
});

T("T-b5", "進捗と残り時間（大5分・小1.5分）", () => {
  const { state, queue } = freshA();
  /* キュー9件 = 大チェック5件（b_rep a_rep a_bfull c_rep c_spot）+ 小チェック4件 */
  eq(KG3.progress(state, queue.items), { total: 9, done: 0, remain: 9, minutes: 5 * 5 + 4 * 1.5 });
  KG3.applyVerdict(state, "b_rep", "pass", "2026-07-19T01:00:00.000Z", "P001");
  eq(KG3.progress(state, queue.items).done, 1);
});

/* =========================================================
   W1-3c  📥📤 契約適合
   ========================================================= */
T("T-c1", "📤書き出しJSONが親書§C形+g3_pass:false追補に適合", () => {
  const { state } = freshA();
  KG3.applyVerdict(state, "b_rep", "pass", "2026-07-19T01:00:00.000Z", "P001");
  KG3.setNote(state, "b_m1", "画面の名前が合わない");
  KG3.applyVerdict(state, "b_m1", "reject", "2026-07-19T01:05:00.000Z", "P001");
  const out = KG3.exportResults(state);
  eq(out.app, "kenshu_g3_desk");
  eq(out.results.length, 2);
  out.results.forEach(r => {
    eq(Object.keys(r).sort(), ["checked_at", "checker", "g3_pass", "mode", "note", "slug"], "キー集合");
    ok(typeof r.g3_pass === "boolean" && typeof r.slug === "string" && (r.mode === "full" || r.mode === "mini"), "型");
  });
  eq(out.results.find(r => r.slug === "b_m1").g3_pass, false);
  eq(out.results.find(r => r.slug === "b_m1").note, "画面の名前が合わない");
  eq(out.results.find(r => r.slug === "b_rep").g3_pass, true);
});

T("T-c2", "deferred / blocked / pending は書き出しに含まれない", () => {
  const { state, lineage } = freshA();
  KG3.applyVerdict(state, "b_m1", "deferred", "2026-07-19T01:00:00.000Z", "P001");
  KG3.setNote(state, "a_rep", "だめ");
  KG3.applyVerdict(state, "a_rep", "reject", "2026-07-19T01:01:00.000Z", "P002");
  KG3.applyBlocking(state, lineage);
  eq(state.items.a_bfull.status, "blocked");
  const got = KG3.exportResults(state).results.map(r => r.slug);
  eq(got, ["a_rep"], "確定した1件だけが出る");
});

T("T-c3", "再取込: slug一致は判定保持・新規は追加・消えたslugはアーカイブへ退避", () => {
  const { p, state } = freshA();
  KG3.applyVerdict(state, "b_rep", "pass", "2026-07-19T01:00:00.000Z", "P001");
  const mod = JSON.parse(textA);
  mod.families[1].members.push({ slug: "b_new", file: "works/cloud_ai/b_new/index.html", score: 60, rank: "A", mode: "mini", spot_check: false });
  mod.families[2].members = mod.families[2].members.filter(m => m.slug !== "c_m2");
  const text2 = JSON.stringify(mod);
  const p2 = KG3.parseLineage(text2);
  ok(p2.hash !== p.hash, "リストが変わればハッシュも変わる");
  const r = KG3.mergeImport(state, p2.lineage, p2.hash, "2026-07-19T02:00:00.000Z");
  eq(r.state.items.b_rep.status, "pass", "既存判定の保持");
  eq(r.state.items.b_new.status, "pending", "新規slugの追加");
  ok(!r.state.items.c_m2, "消えたslugは現役から外れる");
  ok(!!r.state.archived.c_m2, "消えたslugはアーカイブへ退避（判定を捨てない）");
  eq(r.changed, true);
});

T("T-c4", "とりこみのfail-closed: 足りない項目を既定値で埋めない", () => {
  throws(() => KG3.parseLineage(""), "空文字");
  throws(() => KG3.parseLineage("{"), "こわれたJSON");
  throws(() => KG3.parseLineage(JSON.stringify({ app: "other_v1", families: [] })), "別アプリのファイル");
  throws(() => KG3.parseLineage(JSON.stringify({ app: "lineage_v1" })), "familiesなし");
  const base = () => JSON.parse(textA);
  let d = base(); delete d.families[0].members[0].mode;
  throws(() => KG3.parseLineage(JSON.stringify(d)), "modeなし");
  d = base(); delete d.families[0].members[0].spot_check;
  throws(() => KG3.parseLineage(JSON.stringify(d)), "spot_checkなし");
  d = base(); delete d.families[0].members[0].file;
  throws(() => KG3.parseLineage(JSON.stringify(d)), "fileなし");
  d = base(); d.families[0].members[0].score = 120;
  throws(() => KG3.parseLineage(JSON.stringify(d)), "score範囲外");
  d = base(); d.families[0].members[0].rank = "Z";
  throws(() => KG3.parseLineage(JSON.stringify(d)), "rank不正");
  d = base(); d.families[0].representative = "no_such";
  throws(() => KG3.parseLineage(JSON.stringify(d)), "代表がmembersに無い");
});

/* =========================================================
   W1-3d  例外フロー + 一覧
   ========================================================= */
T("T-d1", "代表さしもどし → 同族の未検収兄弟が blocked", () => {
  const { state, lineage } = freshA();
  KG3.setNote(state, "b_rep", "見出しが業務名と違う");
  KG3.applyVerdict(state, "b_rep", "reject", "2026-07-19T01:00:00.000Z", "P001");
  KG3.applyBlocking(state, lineage);
  eq(["b_m1", "b_m2", "b_m3"].map(s => state.items[s].status), ["blocked", "blocked", "blocked"]);
  eq(state.items.a_rep.status, "pending", "他の族は無関係");
});

T("T-d2", "blocked はパック切り出しから除外される", () => {
  const { state, lineage, queue } = freshA();
  KG3.setNote(state, "b_rep", "見出しが業務名と違う");
  KG3.applyVerdict(state, "b_rep", "reject", "2026-07-19T01:00:00.000Z", "P001");
  KG3.applyBlocking(state, lineage);
  const rest = KG3.remainingQueue(state, queue.items);
  eq(slugs(rest), ["a_rep", "a_bfull", "c_rep", "c_m2", "c_spot"]);
  const packs = KG3.buildPacks(rest, state.lineage_hash, 2);
  eq(packs.map(x => slugs(x.items)), [["a_rep", "a_bfull"], ["c_rep", "c_m2"], ["c_spot"]]);
});

T("T-d3", "代表を ごうかく に直すと blocked が解除される（⏸だった件は⏸へ戻る）", () => {
  const { state, lineage } = freshA();
  KG3.applyVerdict(state, "b_m2", "deferred", "2026-07-19T01:00:00.000Z", "P001");
  KG3.setNote(state, "b_rep", "なおす");
  KG3.applyVerdict(state, "b_rep", "reject", "2026-07-19T01:01:00.000Z", "P001");
  KG3.applyBlocking(state, lineage);
  eq(state.items.b_m2.status, "blocked");
  KG3.applyVerdict(state, "b_rep", "pass", "2026-07-19T02:00:00.000Z", "P001");
  KG3.applyBlocking(state, lineage);
  eq(["b_m1", "b_m2", "b_m3"].map(s => state.items[s].status), ["pending", "deferred", "pending"]);
});

T("T-d4", "一覧からの判定し直しは旧判定を置換（件数は増えない）", () => {
  const { state } = freshA();
  KG3.applyVerdict(state, "b_m1", "pass", "2026-07-19T01:00:00.000Z", "P001");
  const n1 = Object.keys(state.items).length;
  const e1 = KG3.exportResults(state).results.length;
  KG3.setNote(state, "b_m1", "やっぱり画面が違う");
  KG3.applyVerdict(state, "b_m1", "reject", "2026-07-19T03:00:00.000Z", "single");
  eq(Object.keys(state.items).length, n1, "件数が増えた");
  eq(KG3.exportResults(state).results.length, e1, "書き出し件数が増えた");
  const r = KG3.exportResults(state).results[0];
  eq([r.slug, r.g3_pass, r.checked_at], ["b_m1", false, "2026-07-19T03:00:00.000Z"], "上書きされていない");
});

/* =========================================================
   コーナーケース（親書§G-6）
   ========================================================= */
T("T-x1", "空のけんしゅうリスト / 0件族 は落ちずに警告", () => {
  const p = KG3.parseLineage(JSON.stringify({ app: "lineage_v1", families: [] }));
  eq(p.warnings.length, 1);
  const q = KG3.buildQueue(p.lineage);
  eq(q.items.length, 0);
  eq(KG3.buildPacks(q.items, p.hash, 2).length, 0);
  const d = JSON.parse(textA);
  d.families.push({ family_key: "tool|出荷|単画面", representative: "x", members: [] });
  throws(() => KG3.parseLineage(JSON.stringify(d)), "0件族で代表が居ないのは止める");
});

T("T-x2", "slug重複は警告のうえ最初の1件だけ使う（落ちない）", () => {
  const d = JSON.parse(textA);
  d.families[0].members.push({ slug: "b_m1", file: "works/cloud_ai/dup/index.html", score: 10, rank: "A", mode: "mini", spot_check: false });
  const p = KG3.parseLineage(JSON.stringify(d));
  ok(p.warnings.some(w => w.indexOf("b_m1") >= 0), "重複の警告が出ない");
  const q = KG3.buildQueue(p.lineage);
  eq(q.items.filter(x => x.slug === "b_m1").length, 1, "重複が二重に入った");
});

T("T-x3", "巨大メモ（1万字）と <script> 入りメモ: 落ちない・esc()が効く", () => {
  const { state } = freshA();
  const big = "あ".repeat(10000);
  KG3.setNote(state, "b_rep", big);
  eq(state.items.b_rep.note.length, 10000);
  KG3.setNote(state, "b_rep", '<script>alert(1)<\/script>&"\'');
  KG3.applyVerdict(state, "b_rep", "reject", "2026-07-19T01:00:00.000Z", "P001");
  const e = KG3.esc(state.items.b_rep.note);
  ok(e.indexOf("<script") < 0 && e.indexOf("&lt;script&gt;") >= 0, "escが効いていない: " + e);
  eq(KG3.exportResults(state).results[0].note, '<script>alert(1)<\/script>&"\'', "書き出しは元の文字のまま");
});

T("T-x4", "1パックの枠数を設定で変えても決定論（枠数1・3）", () => {
  const { p, queue } = freshA();
  eq(KG3.buildPacks(queue.items, p.hash, 1).map(x => slugs(x.items)),
    [["b_rep"], ["b_m1", "b_m2", "b_m3"], ["a_rep"], ["a_bfull"], ["c_rep"], ["c_m2"], ["c_spot"]]);
  eq(KG3.buildPacks(queue.items, p.hash, 3).map(x => slugs(x.items)),
    [["b_rep", "b_m1", "b_m2", "b_m3"], ["a_rep", "a_bfull"], ["c_rep", "c_m2", "c_spot"]]);
});

/* =========================================================
   決裁ぶん（closed_decisions.jsonl 実測: DB-372 / DB-373 / DB-374）
   ========================================================= */
T("T-f1", "DB-372 数字キー: 1=ごうかく 2=さしもどす 3=あとで／つかわない ときは 何も起きない", () => {
  eq(KG3.verdictForKey("1", true), "pass");
  eq(KG3.verdictForKey("2", true), "reject");
  eq(KG3.verdictForKey("3", true), "deferred");
  eq(KG3.verdictForKey("4", true), null, "わりあての ない キー");
  eq(KG3.verdictForKey("a", true), null);
  ["1", "2", "3"].forEach(k => eq(KG3.verdictForKey(k, false), null, "既定OFFで反応した: " + k));
  eq(KG3.verdictForKey("1", undefined), null, "設定なしは OFF あつかい（fail-closed）");
  eq(KG3.verdictForKey("1", "on"), null, "真偽値いがいは OFF あつかい");
});

T("T-f2", "DB-372 数字キーの2（さしもどす）でも 理由必須ガードは 外れない", () => {
  const { state } = freshA();
  const kind = KG3.verdictForKey("2", true);
  eq(kind, "reject");
  throws(() => KG3.applyVerdict(state, "b_rep", kind, "2026-07-19T01:00:00.000Z", "P001"), "理由なしで通った");
  eq(state.items.b_rep.status, "pending");
  KG3.setNote(state, "b_rep", "見出しが ちがう");
  KG3.applyVerdict(state, "b_rep", kind, "2026-07-19T01:00:00.000Z", "P001");
  eq(state.items.b_rep.status, "reject");
});

T("T-f3", "DB-373 checker: 既定は「干場」・設定の名前が判定と書き出しに載る", () => {
  eq(KG3.CHECKER_NAME, "干場", "既定値");
  const { state } = freshA();
  KG3.applyVerdict(state, "b_rep", "pass", "2026-07-19T01:00:00.000Z", "P001");
  eq(state.items.b_rep.checker, "干場", "指定なしは既定");
  KG3.applyVerdict(state, "b_m1", "pass", "2026-07-19T01:01:00.000Z", "P001", "山田");
  eq(state.items.b_m1.checker, "山田", "設定の名前が入らない");
  const res = KG3.exportResults(state).results;
  eq(res.find(r => r.slug === "b_m1").checker, "山田", "書き出しに載らない");
  eq(res.find(r => r.slug === "b_rep").checker, "干場", "既定の件が上書きされた");
  eq(KG3.normalizeChecker("  佐藤  "), "佐藤", "前後の空白を落とす");
  throws(() => KG3.normalizeChecker(""), "空の名前が通った");
  throws(() => KG3.normalizeChecker("   "), "空白だけの名前が通った");
  throws(() => KG3.normalizeChecker("あ".repeat(21)), "長すぎる名前が通った");
  throws(() => KG3.applyVerdict(state, "b_m2", "pass", "2026-07-19T01:02:00.000Z", "P001", "  "),
    "空の名前で判定できた（fail-closed）");
});

T("T-f4", "DB-374「古い」印: 経過日数と しきい値の判定が決定論", () => {
  const t0 = "2026-07-10T09:00:00.000Z";
  eq(KG3.ageDays(t0, "2026-07-10T23:59:59.000Z"), 0);
  eq(KG3.ageDays(t0, "2026-07-17T08:59:59.000Z"), 6, "24時間未満は繰り上げない");
  eq(KG3.ageDays(t0, "2026-07-17T09:00:00.000Z"), 7);
  eq(KG3.isStale(t0, "2026-07-17T08:59:59.000Z", 7), false, "しきい値の手前");
  eq(KG3.isStale(t0, "2026-07-17T09:00:00.000Z", 7), true, "しきい値ちょうどで古い");
  eq(KG3.isStale(t0, "2026-07-12T09:00:00.000Z", 1), true, "しきい値を設定で変えられる");
  eq(KG3.STALE_DAYS_DEFAULT, 7, "既定の日数");
  /* fail-closed: 前提が無い/こわれている時は 黙って「古くない」に倒さず 例外 */
  throws(() => KG3.ageDays(null, "2026-07-17T09:00:00.000Z"), "読みこんだ日時なしが通った");
  throws(() => KG3.ageDays(t0, null), "いまの日時なしが通った");
  throws(() => KG3.ageDays("きのう", "2026-07-17T09:00:00.000Z"), "こわれた日時が通った");
  throws(() => KG3.isStale(t0, "2026-07-17T09:00:00.000Z", 0), "日数0が通った");
  throws(() => KG3.isStale(t0, "2026-07-17T09:00:00.000Z", "7"), "文字の日数が通った");
});

T("T-f5", "取込した state から そのまま「古い」判定ができる", () => {
  const p = KG3.parseLineage(textA);
  const r = KG3.mergeImport(null, p.lineage, p.hash, "2026-07-01T00:00:00.000Z");
  eq(r.state.imported_at, "2026-07-01T00:00:00.000Z");
  eq(KG3.isStale(r.state.imported_at, "2026-07-19T00:00:00.000Z", 7), true);
  eq(KG3.isStale(r.state.imported_at, "2026-07-03T00:00:00.000Z", 7), false);
});

/* =========================================================
   W1-3e  静的検査（G1外部参照0 / A11y / 5本柱）
   ========================================================= */
const bodyText = (() => {
  let s = html.replace(/<script[\s\S]*?<\/script>/g, " ").replace(/<style[\s\S]*?<\/style>/g, " ")
    .replace(/<!--[\s\S]*?-->/g, " ").replace(/<[^>]+>/g, " ");
  return s.replace(/\s+/g, " ");
})();

T("T-e1", "G1: 外部参照ゼロ（CDN・外部URL・npm依存なし）", () => {
  const bad = html.match(/https?:\/\//g) || [];
  eq(bad, [], "外部URLがある");
  ok(!/<script[^>]+src=/i.test(html), "外部scriptがある");
  ok(!/<link[^>]+stylesheet/i.test(html), "外部cssがある");
  ok(!/@import/.test(html), "@importがある");
});

T("T-e2", "単一HTML・ビルド無し・localStorageキーは契約どおり", () => {
  const keys = Array.from(new Set((html.match(/kenshu_g3[a-z0-9_]*_v1/g) || [])));
  eq(keys.sort(), ["kenshu_g3_desk_cfg_v1", "kenshu_g3_lineage_v1", "kenshu_g3_v1"].sort(),
    "localStorageキーが契約外");
  ok(/<html lang="ja">/.test(html), "lang=ja がない");
  ok(/<meta name="genre"/.test(html), "genre がない");
});

T("T-e3", "必須導線: 📤書き出し・❓使い方・アイコン絵文字", () => {
  ok(/📤/.test(html), "📤がない");
  ok(/❓/.test(html), "❓がない");
  ok(/<title>[^<]*✅/.test(html), "タイトルにアイコンがない");
  ok(/createObjectURL/.test(html), "書き出しの実装がない");
  ok(/FileReader/.test(html), "読みこみの実装がない");
});

T("T-e4", "A11y: 44px・フォーカス可視・aria-live・ラベル関連付け・色だけに頼らない", () => {
  ok(/min-height:44px/.test(html) && /min-width:44px/.test(html), "44pxの指定がない");
  ok(/:focus-visible/.test(html), "フォーカス可視がない");
  ok(/aria-live="polite"/.test(html), "aria-liveがない");
  ok(/setAttribute\("for"/.test(html) || /<label[^>]+for=/.test(html), "labelのfor関連付けがない");
  ok(/aria-pressed/.test(html), "選択状態の文字符号（aria-pressed）がない");
  const st = ["✅ ごうかく", "↩ さしもどし", "⏸ あとで", "⛔ まちB"];
  st.forEach(x => ok(html.indexOf(x) >= 0, "状態の文字表示がない: " + x));
});

T("T-e5", "やさしい日本語: 禁止語・二重否定・範囲記号・日付の区切りが画面文言にない", () => {
  const banned = ["適宜", "下さい", "ごろ", "おそらく", "結構です", "ましょう",
    "なくはない", "ないことはない", "以外は必要ない", "〜"];
  const hit = banned.filter(w => bodyText.indexOf(w) >= 0);
  eq(hit, [], "禁止語がUI文言にある");
  ok(!/\d+年\d+\/\d+/.test(bodyText), "日付の／区切りがある");
});

T("T-e6", "gentle slope: 段階2の設定パネルと段階3の✎編集ポイントがある", () => {
  ok(/kenshu_g3_desk_cfg_v1/.test(html), "設定の保存先がない");
  ok(/さいしょに もどす/.test(bodyText), "初期値に戻すボタンがない");
  ok((html.match(/✎編集ポイント/g) || []).length >= 2, "✎編集ポイントが足りない");
});

T("T-e8", "決裁3件が画面に出ている（設定欄・数字キー処理・「古い」印）", () => {
  ["cfgChecker", "cfgKeys", "cfgStale"].forEach(id => ok(html.indexOf('id="' + id + '"') >= 0, "設定欄がない: " + id));
  ok(/addEventListener\("keydown"/.test(html), "数字キーの受け口がない");
  ok(/verdictForKey/.test(html), "数字キーの判定を使っていない");
  ok(/tag==="INPUT"/.test(html), "文字を打つ欄で数字キーを止めるガードがない");
  ok(bodyText.indexOf("古いです") >= 0, "「古い」印の文言がない");
  ok(/function showDone\(\)\{[\s\S]{0,200}renderStale\(\);/.test(html), "パック完了画面で「古い」印を出す呼び出しがない");
  ok(/isStale\(state\.imported_at/.test(html), "「古い」判定に読みこんだ日時を渡していない");
  ok(bodyText.indexOf("1=ごうかく") >= 0, "数字キーの説明が使い方または設定にない");
  const keys = Array.from(new Set((html.match(/kenshu_g3[a-z0-9_]*_v1/g) || [])));
  eq(keys.length, 3, "localStorageキーが増減した");
  ok(/checker:cfg\.checker|cfg\.checker/.test(html), "設定の名前を判定に渡していない");
});

T("T-e7", "B1: 自動送信・自動終了・スケジュール実行がない", () => {
  ok(!/fetch\s*\(/.test(html), "fetchがある");
  ok(!/XMLHttpRequest/.test(html), "通信がある");
  ok(!/navigator\.sendBeacon/.test(html), "自動送信がある");
  const iv = html.match(/setInterval\(/g) || [];
  eq(iv.length, 1, "setIntervalは経過時間の表示1か所だけのはず");
  ok(/cardTime/.test(html), "経過時間の表示がない");
});

/* =========================================================
   変異テスト（W1-3b・変異ベンチ#20の自己適用）
   ========================================================= */
function runSubset(K) {
  /* 判定まわりの中核だけを再実行し、1つでも落ちれば「検知した」とみなす */
  const checks = [
    () => { const { state } = freshA(K); K.applyVerdict(state, "b_rep", "deferred", "2026-07-19T01:00:00.000Z", "P001");
            if (state.items.b_rep.status !== "deferred") { throw new Error("deferredにならない"); } },
    () => { const { state } = freshA(K); let threw = false;
            try { K.applyVerdict(state, "b_m1", "reject", "2026-07-19T01:00:00.000Z", "P001"); } catch (e) { threw = true; }
            if (!threw) { throw new Error("理由なしのさしもどしが通った"); } },
    () => { const { state, lineage } = freshA(K); K.setNote(state, "b_rep", "x");
            K.applyVerdict(state, "b_rep", "reject", "2026-07-19T01:00:00.000Z", "P001");
            K.applyBlocking(state, lineage);
            if (state.items.b_m1.status !== "blocked") { throw new Error("兄弟がblockedにならない"); } },
    () => { const { state } = freshA(K); K.applyVerdict(state, "b_m1", "deferred", "2026-07-19T01:00:00.000Z", "P001");
            if (K.exportResults(state).results.length !== 0) { throw new Error("未確定が書き出された"); } },
    () => { const { state, queue } = freshA(K); K.applyVerdict(state, "b_rep", "deferred", "2026-07-19T01:00:00.000Z", "P001");
            const got = K.remainingQueue(state, queue.items).map(x => x.slug).slice(0, 4).join(",");
            if (got !== "b_m1,b_m2,b_m3,b_rep") { throw new Error("⏸が族末尾に回らない: " + got); } },
    /* 決裁ぶん（DB-372/373/374） */
    () => { const got = ["1", "2", "3"].map(k => K.verdictForKey(k, true)).join(",");
            if (got !== "pass,reject,deferred") { throw new Error("数字キーのわりあてが違う: " + got); }
            if (K.verdictForKey("1", false) !== null) { throw new Error("既定OFFなのに反応する"); } },
    () => { const { state } = freshA(K); K.applyVerdict(state, "b_rep", "pass", "2026-07-19T01:00:00.000Z", "P001", "山田");
            if (state.items.b_rep.checker !== "山田") { throw new Error("設定の名前が入らない"); }
            let threw = false; try { K.normalizeChecker(" "); } catch (e) { threw = true; }
            if (!threw) { throw new Error("空の名前が通る"); } },
    () => { if (K.isStale("2026-07-10T09:00:00.000Z", "2026-07-17T09:00:00.000Z", 7) !== true) { throw new Error("古いと判定しない"); }
            if (K.isStale("2026-07-10T09:00:00.000Z", "2026-07-12T09:00:00.000Z", 7) !== false) { throw new Error("新しいのに古いと言う"); } }
  ];
  /* 各検査は「異常があれば例外を投げる」形。投げた数 = 検知した違反の数 */
  let ng = 0;
  checks.forEach(c => { try { c(); } catch (e) { ng++; } });
  return ng;   /* 0 = 検査すべてを満たす */
}

const MUTANTS = [
  ["M1 判定ハンドラ（⏸あとで）を無効化", s => s.replace("it.status=verdict;", 'it.status=(verdict==="deferred")?"pass":verdict;')],
  ["M2 さしもどしの理由必須ガードを無効化", s => s.replace('if(verdict==="reject" && String(it.note).trim()===""){', "if(false){")],
  ["M3 未確定を書き出しに混ぜる", s => s.replace('if(it.status!=="pass" && it.status!=="reject"){ continue; }', "")],
  ["M4 代表さしもどしの連動を無効化", s => s.replace("var repRejected = !!(rep && rep.status===\"reject\");", "var repRejected = false;")],
  ["M5 ⏸の族末尾回しを無効化", s => s.replace("out=out.concat(byFam[k].pend, byFam[k].defer);", "out=out.concat(byFam[k].pend);")],
  ["M6 数字キーのわりあてを取りちがえる（DB-372）", s => s.replace('"2":"reject"', '"2":"pass"')],
  ["M7 数字キーが既定ONに漏れる（DB-372）", s => s.replace("if(enabled!==true){ return null; }", "if(enabled===null){ return null; }")],
  ["M8 設定の名前を無視して固定名にする（DB-373）", s => s.replace("it.checker=(checker==null) ? (it.checker||CHECKER_NAME) : normalizeChecker(checker);", "it.checker=CHECKER_NAME;")],
  ["M9 空の名前を素通しする（DB-373）", s => s.replace('if(s===""){ throw new Error("かくにんする人の 名前を 入れてください。"); }', "")],
  ["M10「古い」印が出なくなる（DB-374）", s => s.replace("return ageDays(importedAt, nowIso) >= thresholdDays;", "return false;")]
];

T("T-m0", "変異なしの本体は 判定まわりの検査を すべて満たす", () => {
  eq(runSubset(KG3), 0, "本体が自分の検査に落ちている");
});
MUTANTS.forEach(([name, mut], i) => {
  T("T-m" + (i + 1), "変異検知: " + name, () => {
    const src = mut(CORE_SRC);
    ok(src !== CORE_SRC, "変異が適用されていない（置換対象の文字列が変わった可能性）");
    let detected = 0;
    try { detected = runSubset(loadCore(src)); }
    catch (e) { detected = 1; }   /* 読み込み自体が壊れるのも検知 */
    ok(detected > 0, "変異を検知できなかった（テストの穴）");
  });
});

/* ---- 結果 ---- */
console.log("\n===== 結果: " + pass + " PASS / " + fail + " FAIL （合計 " + (pass + fail) + "） =====");
if (fail) { failures.forEach(f => console.log("  - " + f)); process.exit(1); }
